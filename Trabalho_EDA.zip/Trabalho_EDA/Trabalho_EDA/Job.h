/**
*  @file Job.h
 * @author Mariana Carvalho
 * @email a21090@alunos.ipca.pt
 * @date 2022

*/

#pragma once
#include "Maquina.h"
#include "Operacao.h"
#include <stdio.h>

#ifndef HEADER
#define HEADER 1 
typedef struct Job
{
	int cod;
	struct Operacao* operacao;
	struct Job* seguinte;
}Job;

Job* InserirAll(int jobCod, int operCod, int maq, int temp, Job* headlist);
Job* InserirJob(Job* job, Job* headlist);
Job* CriarJob(int jobCod, Job* headlist);
Job* InserirOperacao(Job* job, Operacao* op);
Job* RemoverJob(Job* job);

Operacao* CriarOperacao(int operCod, Job* job);
Operacao* InserirMaquina(Operacao* op, Maquina* maq);
Maquina* CriarMaquina(int maq, int tempo, Operacao* op);

void EscreverFile(Job* job);
Job* LerFile();

Operacao* RemoverOperacao(Operacao* op);
Job* AlterarOperacao(Job* p, int cod, int novoCod);
Job* AlterarMaquina(Job* p, int opCod, int maq, int novamaq, int novotempo);

int Maximo(Job* job);
int Minimo(Job* job);
float CalcularMedia(Operacao* op);

#endif

