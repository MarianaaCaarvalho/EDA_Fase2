/**
*  @file Maquina.h
 * @author Mariana Carvalho
 * @email a21090@alunos.ipca.pt
 * @date 2022

*/

#include <stdio.h>
#include "Job.h"
#include "Operacao.h"
#ifndef HEADER3
#define HEADER3 1

#pragma once
typedef struct Maquina
{
	int maquina;
	int tempo;
	struct Maquina* seguinte;
}Maquina;

#endif // !HEADER



