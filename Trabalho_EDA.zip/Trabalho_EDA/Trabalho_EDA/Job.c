/**
*  @file Job.c
 * @author Mariana Carvalho
 * @email a21090@alunos.ipca.pt
 * @date 2022

*/

#define _CRT_SECURE_NO_WARNINGS
#include "Job.h"
#include "Operacao.h"
#include "Maquina.h"
#include <stdio.h>

void EscreverFile(Job* job)
{
	FILE* fj;

	fj = fopen("Job.txt", "w");

	while (job)
	{
		while (job->operacao)
		{
			while (job->operacao->maquinaO)
			{
				fprintf(fj, "%d;%d;%d;%d\n", job->cod, job->operacao->cod, job->operacao->maquinaO->maquina, job->operacao->maquinaO->tempo);
				job->operacao->maquinaO = job->operacao->maquinaO->seguinte;
			}
			job->operacao = job->operacao->seguinte;
		}
		job = job->seguinte;
	}

	fclose(fj);
}

Job* LerFile()
{
	FILE* fj;
	int jobCod, opCod, maq, tem;

	Job* job = NULL;

	fj = fopen("Job.txt", "r");

	if (fj)
	{
		do
		{
			fscanf(fj, "%d;%d;%d;%d", &jobCod, &opCod, &maq, &tem);
			job = InserirAll(jobCod, opCod, maq, tem, job);
			if (feof(fj))
			{
				break;
			}
		} while (1);
	}
	
}

Job* InserirAll(int jobCod, int operCod, int maq, int temp, Job* headlist)
{
	headlist = CriarJob(jobCod, headlist);
	headlist = CriarOperacao(operCod, headlist);
	headlist->operacao = CriarMaquina(maq, temp, headlist->operacao);

	return headlist;
}

/*
	* @brief Cria um novo job
	* @param[in] jobcod    Codigo do job que se pretende criar
	* @return    Novo job
*/
Job* CriarJob(int jobCod, Job* headlist)
{
	Job* novojob = (Job*)malloc(sizeof(Job));

	if (!novojob)
	{
		return NULL;
	}

	novojob->cod = jobCod;
	novojob->operacao = NULL;
	novojob->seguinte = NULL;

	return InserirJob(novojob, headlist);
}

/*
	* @brief Insere um novo job no in�cio da lista de Jobs
	* @param[in] headlist    Lista de Jobs
	* @param[in] job         job que se pretende inserir na lista
	* @return    Lista de jobs
*/
Job* InserirJob(Job * job, Job * headlist)
{
	if (!headlist)       //verifica se a lista de Jobs � nula
	{
		return job;     //se for nula, devolve o Job que se pretende inserir
	}

	if (!job)		//verifica se o Job � nulo
	{
		return headlist;   //se for nulo devolve a lista de Jobs
	}

	if (ExisteJob(headlist, job->cod) == 1)  //verifica se j� existe o Job pretendido e se existir n�o insere e devolve a lista de Jobs inicial
	{
		return headlist;
	}
	
	job->seguinte = headlist;  
	headlist = job;
	return headlist;
}

/*
	* @brief Pesquisa por um Job
	* @param[in] job	estrutura onde se vai procurar o Job
	* @param[in] jobCod	codigo do Job que se pretende procurar
	* return	Estrutura do Job que se pesquisou
*/
Job* ProcurarJob(Job* job, int jobCod)
{
	if (!job || job->cod == jobCod)
	{
		return job;
	}
	else
	{
		return ProcurarJob(job->seguinte, jobCod);
	}
}

/*
	* @brief Verifica se existe um job, atrav�s do seu codigo
	* @param[in] job    lista de jobs
	* @param[in] codigo    codigo do job
	* @return    1 se existir o job, 0 se n�o existr
*/
int ExisteJob(Job* job, int codigo)
{
	if (job == NULL)
	{
		return 0;
	}
	
	Job* aux = job;
	while (aux != NULL)
	{
		if (aux->cod == codigo)
		{
			return 1;
		}
		else
		{
			aux = aux->seguinte;
		}
	}
	return 0;
}

/*
	* @brief	Remove os jobs selecionados
	* @param[in]op	 Estrutura do job que se pretende remover
	* @return	 Lista de jobs sem o job que se pretendia remover
*/
Job* RemoverJob(Job* job)
{
	Operacao* aux = job->operacao;
	Job* toDelete = job;
	job = toDelete->seguinte;
	while (aux != NULL)
	{
		Operacao* aux2 = aux;
		aux->seguinte = aux2->seguinte;
		RemoverOperacao(aux2);

	}
	free(toDelete);

	return job;

}

/*
	* @brief Calcula a maquina com o menor tempo 
	* @param[in] op    opera��o com x m�quinas
	* @return    Maquina com o menor tempo 
*/
Maquina* TempoMin(Operacao* op)
{

	if (!op)
	{
		return NULL;
	}

	if (!op->maquinaO)
	{
		return NULL;
	}
	Maquina* aux = op->maquinaO;
	Maquina* aux2 = op->maquinaO->seguinte;

	while (aux2)
	{
		if (aux->tempo > aux2->tempo)		
		{
			aux = aux2;
		}
		aux2 = aux2->seguinte;
	}
	return aux;			
}

/*
	* @brief Calcula a maquina com o mair tempo
	* @param[in] op    opera��o com x m�quinas
	* @return    Maquina com o maior tempo
*/
Maquina* TempoMax(Operacao* op)
{

	if (!op)
	{
		return NULL;
	}


	if (!op->maquinaO)
	{
		return NULL;
	}
	Maquina* aux = op->maquinaO;
	Maquina* aux2 = op->maquinaO->seguinte;

	while (aux2)
	{
		if (aux->tempo < aux2->tempo)		
		{
			aux = aux2;
		}
		aux2 = aux2->seguinte;
	}
	return aux;			
}

/*
	* @brief Calcula a media de tempo das maquinas de uma certa opera��o
	* @param[in] op    opera��o
	* @return    Media de todas as maquina de uma opera��o
*/
float CalcularMedia(Operacao* op)
{
	float media = 0, x = 0;
	if (!op)
	{
		return 0;
	}

	while (op->maquinaO)
	{
		media += op->maquinaO->tempo;
		op->maquinaO = op->maquinaO->seguinte;
		x++;
	}

	media = media / x;

	return media;
}

/*
	* @brief Calcula o tempo minimo necessario para realizar todas as opera��es de um job
	* @param[in] job    
	* @return    Tempo minimo necessario para realizar todas as opera��es do job
*/
int Minimo(Job* job)
{
	Maquina* aux;
	Job* aux2 = job;

	int soma = 0;

	if (!job)
	{
		return 0;
	}

	while (aux2->operacao)
	{
		aux = TempoMin(aux2->operacao);	
		if (aux)
		{
			MostrarMaquina(aux, aux2->operacao->cod);		
			soma += aux->tempo;
		}
		aux2->operacao = aux2->operacao->seguinte;	
	}

	return soma;
}

/*
	* @brief Calcula o tempo maximo necessario para realizar todas as opera��es de um job
	* @param[in] job
	* @return    Tempo maximo necessario para realizar todas as opera��es do job
*/
int Maximo(Job* job)
{
	Maquina* aux;
	Job* aux2 = job;
	int soma = 0;

	if (!job)
	{
		return 0;
	}

	while (aux2->operacao)
	{
		aux = TempoMax(aux2->operacao);	
		if (aux)
		{
			MostrarMaquina(aux, aux2->operacao->cod);		
			soma += aux->tempo;
		}
		aux2->operacao = aux2->operacao->seguinte;	
	}

	return soma;
}

/*
	* @brief Calcula a media para cada opera��o de um job
	* @param[in] job
*/
void Media(Job* job)
{
	int media;
	Operacao* aux = job->operacao;

	while (aux)
	{
		media = CalcularMedia(aux);
		aux = aux->seguinte;
	}
}

	

