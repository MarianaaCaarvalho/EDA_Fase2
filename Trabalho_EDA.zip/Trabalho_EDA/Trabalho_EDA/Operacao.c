/**
*  @file Operacao.c
 * @author Mariana Carvalho
 * @email a21090@alunos.ipca.pt
 * @date 2022

*/

#define _CRT_SECURE_NO_WARNINGS
#include "Operacao.h"
#include "Job.h"
#include "Maquina.h"
#include <stdio.h>

/*
	* @brief Cria uma nova opera��o
	* @param[in] opercod    Codigo da opera��o que se pretende criar
	* @return    Nova opera��o
*/
Operacao* CriarOperacao(int operCod, Job* job)		
{
	Operacao* novaoper = (Operacao*)malloc(sizeof(Operacao));

	if (!novaoper)
	{
		return NULL;
	}

	novaoper->cod = operCod;
	novaoper->maquinaO = NULL;
	novaoper->seguinte = NULL;

	return InserirOperacao(novaoper, job);
}

/*
	* @brief		Insere uma opera�ao dentro de um job
	* @param[in]job Lista de jobs onde vai ser inserida a opera�ao
	* @param[in]op  Opera�ao que se pretende inserir
	* @return		Estrutura job onde foi inserida a opera��o
*/
Job* InserirOperacao(Job* job, Operacao* op)	
{
	if (!job)
	{
		return NULL;
	}
	if (!op)
	{
		return NULL;
	}

	if (!job->operacao)		
	{
		job->operacao = op;
	}
	else
	{
		if (ExisteOperacao(job->operacao, op->cod) == 1)
		{
			return job;
		}
		else
		{
			op->seguinte = job->operacao;
			job->operacao = op;			
		}
	}

	return job;
}

/*
	* @brief	Fun��o auxiliar para a remo��o de opera��es
	* @param[in]op	opera��o que se pretende remover
	* return Lista ligada sem a opera��o removida
*/
Operacao* ToDelete(Operacao* op)
{
	Operacao* toDelete = op;
	op = toDelete->seguinte;
	free(toDelete);

	return op;
}

/*
	* @brief	Remove as opera��es e as m�quinas associadas
	* @param[in]op	 Estrutura da operacao que se pretende remover
	* @return	 Lista de opera��es sem a opera��o que se pretendia remover
*/
Operacao* RemoverOperacao(Operacao* op)
{
	Maquina* aux = op->maquinaO;
	Operacao* toDelete = op;
	op = toDelete->seguinte;
	while (aux != NULL)
	{
		Maquina* aux2 = aux;
		aux->seguinte = aux2->seguinte;
		RemoverMaquina(aux2);

	}
	free(toDelete);

	return op;
}

/*
	* @brief Pesquisa opera��es
	* @param[in]oper	Estrutura onde se vai procurar a opera��o
	* @param[in]operCod	Codigo da opera��o que se pretende procurar
	* return	Estrutura da opera��o que se pesquisou 
*/
Operacao* ProcurarOperacao(Operacao* oper, int operCod)
{
	if (!oper || oper->cod == operCod)
	{
		return oper;
	}
	else
	{
		return ProcurarOperacao(oper->seguinte, operCod);
	}
}

/*
	* @brief Altera uma opera��o de uma lista de jobs
	* @param[in]p	 Lista de jobs
	* @param[in]cod	 Codigo da opera��o que se pretede alterar
	* @param[in]novoCod	 Novo c�digo da opera��o
	* return	Lista de jobs com o novo c�digo na opera��o que se alterou
*/
Job* AlterarOperacao(Job* p, int cod, int novoCod)
{
	Operacao* aux;

	if (!p)
	{
		return NULL;
	}

	aux = ProcurarOperacao(p->operacao, cod);
	aux->cod = novoCod;

	return p;
}

/*
	* @brief	Verifica se existe determinada opera��o na lista
	* @param[in]op			Lista de opera��es
	* @param[in]codigo		Codigo da opera��o que se pretende verificar se existe
	* return 1 se existir a opera��o, 0 se n�o existir
*/
int ExisteOperacao(Operacao* op, int codigo)
{
	Operacao* aux = op;

	if (op == NULL)
	{
		return 0;
	}

	while (aux)
	{
		if (aux->cod == codigo)
		{
			return 1;
		}
		else
		{
			aux = aux->seguinte;
		}
	}

	return 0;
}






