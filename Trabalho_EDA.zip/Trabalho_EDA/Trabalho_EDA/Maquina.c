/**
*  @file Maquina.c
 * @author Mariana Carvalho
 * @email a21090@alunos.ipca.pt
 * @date 2022

*/

#define _CRT_SECURE_NO_WARNINGS
#include "Operacao.h"
#include "Maquina.h"
#include "Job.h"
#include <stdio.h>

/*
	* @brief Cria uma nova maquina
	* @param[in] maq    maquina que se pretende criar
	* @param[in] tempo    tempo dessa mesma maquina
	* @return    Nova maquina
*/
Maquina* CriarMaquina(int maq, int tempo, Operacao* op)
{
	Maquina* novamaq = (Maquina*)malloc(sizeof(Maquina));

	if (!novamaq)
	{
		return NULL;
	}
	
	novamaq->maquina = maq;
	novamaq->tempo = tempo;
	novamaq->seguinte = NULL;

	return InserirMaquina(novamaq, op);
}

/*
	* @brief Verifica se existe uma maquina, atrav�s do seu nome
	* @param[in] maq    lista de maquinas
	* @param[in] maquina    nome da maquina
	* @return    1 se existir a maquina, 0 se n�o existir
*/
int ExisteMaquina(Maquina* maq, int maquina)
{
	Maquina* aux = maq;

	if (maq == NULL)
	{
		return 0;
	}

	while (aux != NULL)
	{
		if (aux->maquina == maquina)
		{
			return 1;
		}
		else
		{
			aux = aux->seguinte;
		}
	}

	return 0;
}

/*
	* @brief Insere uma nova maquina numa lista de maquinas
	* @param[in] op Lista de opera��es onde se pretende inserir a maquina
	* @param[in] maq Maquina que se pretende inserir
	* @return    Lista de opera��es onde foi inserida a maquina
*/
Operacao* InserirMaquina(Operacao* op, Maquina* maq)
{
	if (!op)
	{
		return NULL;
	}
	if (!maq)
	{
		return NULL;
	}

	if (!op->maquinaO)			
	{
		op->maquinaO = maq;
	}
	else
	{
		if (ExisteMaquina(op->maquinaO, maq->maquina) == 1)
		{
			return op;
		}
		else
		{
			maq->seguinte = op->maquinaO;
			op->maquinaO = maq;
		}
	}

	return op;
}

/*
	* @brief Pesquisa por maquinas
	* @param[in] maq	estrutura onde se vai procurar a maquina
	* @param[in] maquina	nome da maquina que se pretende procurar
	* return	Estrutura da maquina que se pesquisou
*/
Maquina* ProcurarMaquina(Maquina* maq, int maquina)
{
	if (!maq || maq->maquina == maquina)
	{
		return maq;
	}
	else
	{
		return ProcurarMaquina(maq->seguinte, maquina);
	}
}

/*
	* @brief	Escreve na consola a respetiva opera��o e o tempo da maquina que se pretende ver
	* @param[in]maq	 Estrutura da maquina que se pretende ver
	* @param[in]cod	 Codigo da opera��o onde a maquina est� inserida 
*/
void MostrarMaquina(Maquina* maq, int cod)
{
	if (maq)
	{
		printf("Operacao: %d\t", cod);
		printf("Maquina: %d\t", maq->maquina);
		printf("Tempo: %d\n", maq->tempo);
	}
}

/*
* @brief  Altera uma maquina de uma lista de opera��es
* @param[in]p				Lista de jobs
* @param[in]opcod			Codigo da opera��o
* @param[in]maq				Codigo da maquina a alterar
* @param[in]novamaq			Nova maquina para alterar
* @param[in]novotempo		Novo tempo para alterar
* return	Lista de jobs com as opera��es com a nova maquina e novo tempo
*/
Job* AlterarMaquina(Job* p, int opCod, int maq, int novamaq, int novotempo)
{
	Maquina* aux;
	Operacao* aux2;

	if (!p)
	{
		return NULL;
	}

	aux2 = ProcurarOperacao(p->operacao, opCod);
	aux = ProcurarMaquina(aux2->maquinaO, maq);

	if (aux)
	{
		aux->maquina = novamaq;
		aux->tempo = novotempo;
	}

	return p;
}

/*
	* @brief	Remove as m�quinas
	* @param[in]maq	 Estrutura da maquina que se pretende remover
	* @return	 Lista de m�quinas sem a m�quina que se pretendia remover
*/
Maquina* RemoverMaquina(Maquina* maq)
{
	Maquina* toDelete = maq;
	maq = toDelete->seguinte;
	free(toDelete);

	return maq;
}

