/**
*  @file Operacao.h
 * @author Mariana Carvalho
 * @email a21090@alunos.ipca.pt
 * @date 2022

*/

#include <stdio.h>
#include "Job.h"
#ifndef HEADER2
#define HEADER2 1

#pragma once
typedef struct Operacao
{
	int cod;
	struct Maquina* maquinaO;
	struct Operacao* seguinte;
}Operacao;


#endif

